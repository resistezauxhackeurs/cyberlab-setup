APT:
- apt/manual-packages.txt : paquets marqués manuels par apt-mark.
- apt/all-installed-packages.tsv : inventaire complet et versions.
Python:
- python/pip-freeze.txt : paquets visibles via python3 -m pip freeze --all.
- python/pipx-packages.txt / pipx-list.json : applications pipx.
system:
- sources APT et keyrings archivés pour référence.

Le restore installe les paquets APT manuels, recrée les applications pipx
par nom et installe le pip freeze dans /opt/kali-tools-venv.

Limites:
- pip ne concerne que l'interpréteur python3 par défaut, pas tous les venvs.
- pipx est réinstallé par nom, pas avec une garantie de versions identiques.
- Les dépôts tiers ne sont pas réactivés automatiquement : vérifier leur
  compatibilité et leur authenticité avant de les réutiliser.
- Les outils Git clonés, binaires compilés et configurations applicatives
  ne sont pas sauvegardés par ce script.
- Des paquets présents dans pip freeze peuvent dépendre de bibliothèques APT.
